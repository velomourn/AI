import { anomalyDetection } from './anomalyDetection.js';
app.use(anomalyDetection);