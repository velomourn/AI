import React from 'react';
export default function SocialConnect() {
  return (
    <div>
      <h3>Connect Social Media</h3>
      <a href="http://localhost:5000/api/auth/twitter">
        <button>Connect Twitter</button>
      </a>
    </div>
  );
}